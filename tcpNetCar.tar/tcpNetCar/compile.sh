gcc -o client  client.c  tcp_net_socket.c bcm2835.c pwm.c -lpthread
