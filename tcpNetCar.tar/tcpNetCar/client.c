#include <stdio.h>
#include "tcp_net_socket.h"

#include "pwm.h"

char buffer[1024];
//ssize_t size = 0;

#define INTERVALUE 500
int pwmData0=INTERVALUE;
int pwmData1=INTERVALUE;
int scaleNUM=1;
int heartbeatFlag=0;

#define scalePWM(a)		1200+a*1.2
char buf[1024];
void servoStop()  //cannot set a value in a large interval
{
/*		pwmData0= INTERVALUE;
		pwmData(0, scalePWM(pwmData0) );*/
		int i, differValue, polariFlag;
		differValue = pwmData0-INTERVALUE;
		polariFlag =1;
		if(differValue<0)
		{
				differValue = INTERVALUE-pwmData0;
				polariFlag = 0;
		}
		for(i=0; i<differValue; i++)
		{
				usleep(10);
				if(polariFlag>0)
				{
						pwmData0--;
				}
				else
				{
						pwmData0++;
				}
				pwmData(0, scalePWM(pwmData0) );
		}
}

int servoPwm(char mode)
{
	switch(mode){
		case '1':
			scaleNUM = 1;
			break;
		case '2':
			scaleNUM = 10;
			break;
		case '3':
			scaleNUM = 50;
			break;
		case 'w':
			pwmData0 -= scaleNUM;
			break;
		case 's':
			pwmData0 += scaleNUM;
			break;
		case 'a':
			pwmData1 -= scaleNUM;
			break;
		case 'd':
			pwmData1 += scaleNUM;
			break;
		case '0':
			heartbeatFlag = 1;
			break;
		case 'q':
			servoStop();
			break;
		default:
			break;
	}
	if(pwmData0>1000)
		pwmData0=1000;
	if(pwmData0<0)
		pwmData0=0;
	if(pwmData1>1000)
		pwmData1=1000;
	if(pwmData1<0)
		pwmData1=0;

	pwmData(0, scalePWM(pwmData0) );
//	pwmData(0, 2400);
	printf("%d\n", pwmData0);
	pwmData(1, scalePWM(pwmData1) );
	if((mode=='w')||(mode=='s'))
			return pwmData0;
	if((mode=='a')||(mode=='d'))
			return pwmData1;
}

int main()
{
	int sfd;
	int ret;
	int size;
//	sfd = tcp_connect("119.23.240.131", 8890);
	sfd = tcp_connect("192.168.1.106", 8890);

	pwmInit();

	pwmData(0, 1800);
//	send(sfd, "hello", 6, 0);
//	printf("不阻塞\n");

	while(1)
	{
		size = read(sfd, buf, 1);
		if(size==0)
		{
			close(sfd);
			return -1;
		}
		if(size >0)
			ret = servoPwm(buf[0]);	

		size = sprintf(buf, "%d", ret);
		size = write(sfd, buf, size);
		if(size==0)
		{
			close(sfd);
			return -1;
		}
	}
//	printf("%s\n", buf);
	
}
