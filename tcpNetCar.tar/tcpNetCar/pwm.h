#ifndef __PWM_H__
#define __PWM_H__
int pwmInit();
int pwmData(int channel, int data);
int pwmClose();
#endif
